//  Copyright (c) 2015 Rob Rix. All rights reserved.

/// Project version number for Result.
extern double ResultVersionNumber;

/// Project version string for Result.
extern const unsigned char ResultVersionString[];

